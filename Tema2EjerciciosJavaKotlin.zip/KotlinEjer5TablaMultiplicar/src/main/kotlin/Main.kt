fun main() {
    print("Ingresa un número: ")
    val numero = readln().toInt()
    for (i in 1..10) {
        println("$numero x $i = ${numero * i}")
    }
}