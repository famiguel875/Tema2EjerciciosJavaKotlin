import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa el número de términos: ");
        int n = scanner.nextInt();
        int a = 0, b = 1;

        System.out.print("Serie Fibonacci: ");
        for (int i = 1; i <= n; i++) {
            System.out.print(a + " ");
            int siguiente = a + b;
            a = b;
            b = siguiente;
        }
        scanner.close();
    }
}