fun main() {
    print("Ingresa un número: ")
    var numero = readln().toInt()
    var invertido = 0

    while (numero != 0) {
        val digito = numero % 10
        invertido = invertido * 10 + digito
        numero /= 10
    }

    println("Número invertido: $invertido")
}
