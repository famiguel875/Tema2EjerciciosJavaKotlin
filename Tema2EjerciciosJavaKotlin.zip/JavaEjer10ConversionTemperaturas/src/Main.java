import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa la temperatura: ");
        double temperatura = scanner.nextDouble();
        System.out.print("¿Convertir a Celsius o Fahrenheit?: ");
        String opcion = scanner.next().toLowerCase();

        if (opcion.equals("celsius")) {
            double celsius = (temperatura - 32) * 5 / 9;
            System.out.println("La temperatura en Celsius es: " + celsius);
        } else if (opcion.equals("fahrenheit")) {
            double fahrenheit = temperatura * 9 / 5 + 32;
            System.out.println("La temperatura en Fahrenheit es: " + fahrenheit);
        } else {
            System.out.println("Opción no válida.");
        }

        scanner.close();
    }
}