import kotlin.math.sqrt

fun main() {
    print("Ingresa un número: ")
    val numero = readln().toInt()
    var esPrimo = true

    if (numero <= 1) {
        esPrimo = false
    } else {
        for (i in 2..sqrt(numero.toDouble()).toInt()) {
            if (numero % i == 0) {
                esPrimo = false
                break
            }
        }
    }

    if (esPrimo) {
        println("El número es primo.")
    } else {
        println("El número no es primo.")
    }
}