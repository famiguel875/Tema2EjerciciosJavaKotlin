import java.util.ArrayList;
import java.util.Scanner;

class Videojuego {
    private final String titulo;
    private final String plataforma;
    private final int horasJugadas;

    public Videojuego(String titulo, String plataforma, int horasJugadas) {
        this.titulo = titulo;
        this.plataforma = plataforma;
        this.horasJugadas = horasJugadas;
    }

    @Override
    public String toString() {
        return "Título: " + titulo + ", Plataforma: " + plataforma + ", Horas Jugadas: " + horasJugadas;
    }
}

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ArrayList<Videojuego> inventario = new ArrayList<>();

    public static void main(String[] args) {
        while (true) {
            int opcion = mostrarMenu();
            switch (opcion) {
                case 1 -> añadirVideojuego();
                case 2 -> eliminarVideojuego();
                case 3 -> mostrarInventario();
                case 4 -> {
                    System.out.println("Saliendo del programa...");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Opción no válida.");
            }
        }
    }

    private static int mostrarMenu() {
        System.out.println("\n--- Menú de Inventario de Videojuegos ---");
        System.out.println("1. Añadir videojuego");
        System.out.println("2. Eliminar videojuego");
        System.out.println("3. Mostrar inventario");
        System.out.println("4. Salir");
        System.out.print("Selecciona una opción: ");
        return scanner.nextInt();
    }

    private static void añadirVideojuego() {
        scanner.nextLine();
        System.out.print("Ingresa el título del videojuego: ");
        String titulo = scanner.nextLine();
        System.out.print("Ingresa la plataforma del videojuego: ");
        String plataforma = scanner.nextLine();
        System.out.print("Ingresa las horas jugadas: ");
        int horasJugadas = scanner.nextInt();
        inventario.add(new Videojuego(titulo, plataforma, horasJugadas));
        System.out.println("Videojuego añadido exitosamente.");
    }

    private static void eliminarVideojuego() {
        if (!inventario.isEmpty()) {
            System.out.println("Inventario actual:");
            for (int i = 0; i < inventario.size(); i++) {
                System.out.println(i + ": " + inventario.get(i));
            }
            System.out.print("Ingresa el índice del videojuego a eliminar: ");
            int index = scanner.nextInt();
            if (index >= 0 && index < inventario.size()) {
                inventario.remove(index);
                System.out.println("Videojuego eliminado.");
            } else {
                System.out.println("Índice no válido.");
            }
        } else {
            System.out.println("El inventario está vacío.");
        }
    }

    private static void mostrarInventario() {
        if (!inventario.isEmpty()) {
            System.out.println("\nInventario de Videojuegos:");
            for (Videojuego videojuego : inventario) {
                System.out.println(videojuego);
            }
        } else {
            System.out.println("El inventario está vacío.");
        }
    }
}
