fun main() {
    print("Ingresa la temperatura: ")
    val temperatura = readln().toDouble()
    print("¿Convertir a Celsius o Fahrenheit?: ")
    val opcion = readln().lowercase()

    when (opcion) {
        "celsius" -> {
            val celsius = (temperatura - 32) * 5 / 9
            println("La temperatura en Celsius es: $celsius")
        }
        "fahrenheit" -> {
            val fahrenheit = temperatura * 9 / 5 + 32
            println("La temperatura en Fahrenheit es: $fahrenheit")
        }
        else -> {
            println("Opción no válida.")
        }
    }
}