fun main() {
    print("Ingresa tu nombre: ")
    val nombre = readlnOrNull()
    println("¡Hola, $nombre!")
}