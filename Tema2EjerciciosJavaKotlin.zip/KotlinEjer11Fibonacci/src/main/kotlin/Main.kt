fun main() {
    print("Ingresa el número de términos: ")
    val n = readln().toInt()
    var a = 0
    var b = 1

    print("Serie Fibonacci: ")
    for (i in 1..n) {
        print("$a ")
        val siguiente = a + b
        a = b
        b = siguiente
    }
}