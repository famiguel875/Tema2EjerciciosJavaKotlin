fun main() {
    print("Ingresa un número: ")
    val numero = readln().toInt()
    if (numero % 2 == 0) {
        println("El número es par.")
    } else {
        println("El número es impar.")
    }
}