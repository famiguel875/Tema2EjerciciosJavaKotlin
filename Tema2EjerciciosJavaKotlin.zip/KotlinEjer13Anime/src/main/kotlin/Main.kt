data class Anime(val nombre: String, val episodios: Int, val genero: String)

fun main() {
    print("Ingresa el nombre del anime: ")
    val nombre = readln()
    print("Ingresa el número de episodios: ")
    val episodios = readln().toInt()
    print("Ingresa el género: ")
    val genero = readln()

    val anime = Anime(nombre, episodios, genero)
    println("Anime: $anime")
}
