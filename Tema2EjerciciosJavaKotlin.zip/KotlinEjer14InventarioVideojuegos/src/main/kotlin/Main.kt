data class Videojuego(val titulo: String, val plataforma: String, val horasJugadas: Int)

fun main() {
    val inventario = mutableListOf<Videojuego>()

    while (true) {
        when (mostrarMenu()) {
            1 -> añadirVideojuego(inventario)
            2 -> eliminarVideojuego(inventario)
            3 -> mostrarInventario(inventario)
            4 -> {
                println("Saliendo del programa...")
                break
            }
            else -> println("Opción no válida.")
        }
    }
}

fun mostrarMenu(): Int {
    println("\n--- Menú de Inventario de Videojuegos ---")
    println("1. Añadir videojuego")
    println("2. Eliminar videojuego")
    println("3. Mostrar inventario")
    println("4. Salir")
    print("Selecciona una opción: ")
    return readln().toIntOrNull() ?: 0
}

fun añadirVideojuego(inventario: MutableList<Videojuego>) {
    print("Ingresa el título del videojuego: ")
    val titulo = readln()
    print("Ingresa la plataforma del videojuego: ")
    val plataforma = readln()
    print("Ingresa las horas jugadas: ")
    val horasJugadas = readln().toIntOrNull() ?: 0
    inventario.add(Videojuego(titulo, plataforma, horasJugadas))
    println("Videojuego añadido exitosamente.")
}

fun eliminarVideojuego(inventario: MutableList<Videojuego>) {
    if (inventario.isNotEmpty()) {
        println("Inventario actual:")
        inventario.forEachIndexed { index, videojuego -> println("$index: $videojuego") }
        print("Ingresa el índice del videojuego a eliminar: ")
        val index = readln().toIntOrNull()
        if (index != null && index in inventario.indices) {
            inventario.removeAt(index)
            println("Videojuego eliminado.")
        } else {
            println("Índice no válido.")
        }
    } else {
        println("El inventario está vacío.")
    }
}

fun mostrarInventario(inventario: List<Videojuego>) {
    if (inventario.isNotEmpty()) {
        println("\nInventario de Videojuegos:")
        inventario.forEach { println(it) }
    } else {
        println("El inventario está vacío.")
    }
}
