fun main() {
    print("Ingresa una frase: ")
    val frase = readln().lowercase()
    var contador = 0

    for (caracter in frase) {
        if (caracter == 'a' || caracter == 'e' || caracter == 'i' || caracter == 'o' || caracter == 'u') {
            contador++
        }
    }

    println("La frase contiene $contador vocales.")
}