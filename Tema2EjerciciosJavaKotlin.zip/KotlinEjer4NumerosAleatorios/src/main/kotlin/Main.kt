import kotlin.math.PI

fun main() {
    print("Ingresa el radio del círculo: ")
    val radio = readln().toDouble()
    val area = PI * radio * radio
    println("El área del círculo es: $area")
}