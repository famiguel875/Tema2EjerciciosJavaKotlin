import java.util.Scanner;

public class ClaseAnime {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa el nombre del anime: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingresa el número de episodios: ");
        int episodios = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Ingresa el género: ");
        String genero = scanner.nextLine();

        Anime anime = new Anime(nombre, episodios, genero);
        anime.mostrarInformacion();
        scanner.close();
    }
}
