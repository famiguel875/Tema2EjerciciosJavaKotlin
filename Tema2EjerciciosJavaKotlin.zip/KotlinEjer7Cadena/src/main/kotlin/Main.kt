fun main() {
    print("Ingresa una cadena: ")
    val cadena = readln()
    val reverso = cadena.reversed()
    println("Cadena al revés: $reverso")
}